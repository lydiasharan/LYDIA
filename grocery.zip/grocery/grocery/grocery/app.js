const { useState, useEffect } = React;

function App() {
    const [theme, setTheme] = useState('#20209f');
    const [menuOpen, setMenuOpen] = useState(false);
    const [counter, setCounter] = useState({
        days: 0,
        hours: 0,
        minutes: 0,
        seconds: 0
    });

    useEffect(() => {
        const countDownDate = new Date("March 1, 2025 00:00:00").getTime();

        const interval = setInterval(() => {
            const now = new Date().getTime();
            const diff = countDownDate - now;
            const second = 1000;
            const minute = second * 60;
            const hour = minute * 60;
            const day = hour * 24;

            setCounter({
                days: Math.floor(diff / day),
                hours: Math.floor((diff % day) / hour),
                minutes: Math.floor((diff % hour) / minute),
                seconds: Math.floor((diff % minute) / second)
            });
        }, 1000);

        return () => clearInterval(interval);
    }, []);

    const changeTheme = (color) => {
        setTheme(color);
        document.documentElement.style.setProperty('--main', color);
    };

    return (
        <div>
            <Header menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
            <Home />
            <Products />
            <Deal counter={counter} />
            <Banner />
            <Contact />
            <Newsletter />
            <Footer />
            <ThemeToggle changeTheme={changeTheme} />
        </div>
    );
}

function Header({ menuOpen, setMenuOpen }) {
    return (
        <header>
            <div className="header">
                <a href="#" className="logo">
                    <i className="fa-solid fa-bag-shopping"></i>Shopy
                </a>
                <form action="" className="SearchBox">
                    <input type="text" placeholder="Search Here..." id="Search" />
                    <label htmlFor="Search" className="fas fa-search"></label>
                </form>
            </div>
            <div className={`MainHeader ${menuOpen ? 'active' : ''}`}>
                <div id="MenuBtn" className={`fas fa-bars ${menuOpen ? 'fa-times' : ''}`} onClick={() => setMenuOpen(!menuOpen)}></div>
                <nav className={`navbar ${menuOpen ? 'active' : ''}`}>
                    <a href="#Home">Home</a>
                    <a href="#Products">Products</a>
                    <a href="#Deal">Deal</a>
                    <a href="#Category">Category</a>
                    <a href="#Contact">Contact</a>
                </nav>
                <div className="icons">
                    <i className="fas fa-shopping-cart"></i>
                    <i className="fas fa-user-circle"></i>
                </div>
            </div>
        </header>
    );
}

function Home() {
    return (
        <section id="Home" className="home">
            <div className="content">
                <span>Fresh & Organic</span>
                <h3>Eat Something Fresh Daily</h3>
                <a href="#" className="btn">Get Started</a>
            </div>
            <div className="img">
                <img src="images/home.png" alt="" />
            </div>
        </section>
    );
}

function Products() {
    const products = [
        { imgSrc: 'images/products6.png', name: 'Natural Almonds', price: '$200.00', discountPrice: '$98.00' },
        // Add more products as needed
    ];

    return (
        <section id="Products" className="products">
            <h1 className="heading">Latest <span>Products</span></h1>
            <div className="boxContainer">
                {products.map((product, index) => (
                    <ProductBox key={index} {...product} />
                ))}
            </div>
        </section>
    );
}

function ProductBox({ imgSrc, name, price, discountPrice }) {
    return (
        <div className="box">
            <span className="dis">-80%</span>
            <div className="icons">
                <i className="fas fa-heart"></i>
                <i className="fas fa-share"></i>
                <i className="fas fa-eye"></i>
            </div>
            <img src={imgSrc} alt="" />
            <h3>{name}</h3>
            <div className="stars">
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
            </div>
            <div className="Price">{price} <span>{discountPrice}</span></div>
            <div className="Quantity">
                <span>Quantity : </span>
                <input type="number" min="2" max="300" value="5" />
                <span>/kg</span>
            </div>
            <a href="#" className="btn">Add To Cart</a>
        </div>
    );
}

function Deal({ counter }) {
    return (
        <section id="Deal" className="deal">
            <div className="content">
                <h1>Deal of The Year</h1>
                <div className="Counter">
                    <div className="box">
                        <h3>{counter.days}</h3>
                        <span>Days</span>
                    </div>
                    <div className="box">
                        <h3>{counter.hours}</h3>
                        <span>Hours</span>
                    </div>
                    <div className="box">
                        <h3>{counter.minutes}</h3>
                        <span>Minutes</span>
                    </div>
                    <div className="box">
                        <h3>{counter.seconds}</h3>
                        <span>Seconds</span>
                    </div>
                </div>
                <a href="#" className="btn">Check The Deal</a>
            </div>
        </section>
    );
}

function Banner() {
    return (
        <section className="BannerConatiner">
            <div className="banner">
                <img src="images/veg.jpeg" alt="" />
                <div className="content">
                    <h3>Special Offer</h3>
                    <a href="#" className="btn">Check Out</a>
                </div>
            </div>
            <div className="banner">
                <img src="images/fruits.jpg" alt="" />
                <div className="content">
                    <h3>Limited Offer</h3>
                    <a href="#" className="btn">Check Out</a>
                </div>
            </div>
        </section>
    );
}

function Contact() {
    return (
        <section id="Contact" className="contact">
            <h1 className="heading">Contact <span>Us</span></h1>
            <form action="">
                <div className="inputBox">
                    <input type="text" placeholder="Enter Your Name" />
                    <input type="email" placeholder="Enter Your Email" />
                </div>
                <div className="inputBox">
                    <input type="number" placeholder="Enter Your Number" />
                    <input type="text" placeholder="Enter Your Subject" />
                </div>
                <textarea placeholder="Enter Your Message" cols="30" rows="10"></textarea>
                <input type="submit" value="Send Message" className="btn" />
            </form>
        </section>
    );
}

function Newsletter() {
    return (
        <section className="newsLetter">
            <h3>Newsletter</h3>
            <form action="">
                <input type="email" placeholder="Enter Your Email" className="box" />
                <input type="submit" value="Submit" className="btn" />
            </form>
        </section>
    );
}

function Footer() {
    return (
        <footer>
            <a href="#">Grocery Store || Easy Coding || All Rights Reserved</a>
        </footer>
    );
}

function ThemeToggle({ changeTheme }) {
    return (
        <div className="themeToggle">
            <i className="ToggleBtn fas fa-cog"></i>
            <h3>Choose Color</h3>
            <div className="buttons">
                <div className="themeBtn" style={{ background: '#20209f' }} onClick={() => changeTheme('#20209f')}></div>
                <div className="themeBtn" style={{ background: '#bc1888' }} onClick={() => changeTheme('#bc1888')}></div>
                <div className="themeBtn" style={{ background: '#2cae6e' }} onClick={() => changeTheme('#2cae6e')}></div>
                <div className="themeBtn" style={{ background: '#ff6922' }} onClick={() => changeTheme('#ff6922')}></div>
                <div className="themeBtn" style={{ background: '#ffbc2e' }} onClick={() => changeTheme('#ffbc2e')}></div>
                <div className="themeBtn" style={{ background: '#ff3131' }} onClick={() => changeTheme('#ff3131')}></div>
            </div>
        </div>
    );
}

// Render the App Component
ReactDOM.render(<App />, document.getElementById('root'));
